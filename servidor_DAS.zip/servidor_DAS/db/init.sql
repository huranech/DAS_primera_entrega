-- Tabla de Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    passwd TEXT NOT NULL
);

-- Tabla de Imagenes
CREATE TABLE IF NOT EXISTS imagenes (
    id SERIAL PRIMARY KEY,
    imagen BYTEA NOT NULL
);

-- Tabla de Dispositivos
CREATE TABLE IF NOT EXISTS dispositivos (
    token TEXT PRIMARY KEY
);