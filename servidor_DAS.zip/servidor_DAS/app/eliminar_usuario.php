<?php
// conexión a la base de datos e inicio de sesión
require_once "db_con.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete"])) {
    // recuperar datos del formulario
    $idUsuario = $_POST["id_usuario"];

    // Preparar la consulta SQL para eliminar el usuario por su ID
    $sqlEliminarUsuario = "DELETE FROM usuarios WHERE id = :id";
    $stmtEliminarUsuario = $conexion->prepare($sqlEliminarUsuario);
    $stmtEliminarUsuario->bindParam(':id', $idUsuario);

    // Ejecutar la consulta
    $resultado = $stmtEliminarUsuario->execute();

    $response = array();

    if ($resultado) {
        $response['success'] = true;
	$response['message'] = "Usuario con ID $idUsuario eliminado correctamente";
	$response['idUsuario'] = -1;
    } else {
        $response['success'] = false;
	$response['message'] = "No se pudo eliminar el usuario con ID $idUsuario";
	$response['idUsuario'] = -1;
    }

    // Devolver la respuesta en formato JSON
    header("Content-Type: application/json");
    echo json_encode($response);
 }
 ?>
