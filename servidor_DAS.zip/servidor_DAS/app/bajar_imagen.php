<?php
// Conexión a la base de datos
require_once "db_con.php";
session_start();

// Array para almacenar la respuesta
$response = array();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["bajar_imagen"])) {
    // Recuperar el ID de la imagen del formulario
    $idImagen = $_POST["id_imagen"];

    // Consultar la base de datos para obtener la imagen
    $sql = "SELECT imagen FROM imagenes WHERE id = :id";
    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':id', $idImagen);
    $stmt->execute();

    // Verificar si la imagen fue encontrada
    if ($stmt->rowCount() > 0) {
	    // Obtener los datos binarios de la imagen
	$imagenBinaria = stream_get_contents($stmt->fetchColumn());
        $imagenBase64 = base64_encode($imagenBinaria);
	$response["message"] = gettype($imagenBase64);
        // Agregar la imagen binaria a la respuesta
        $response["imagen"] = $imagenBase64;
	$response["success"] = true;
	$response["idImagen"] = -1;
        //$response["message"] = "La imagen se ha obtenido correctamente desde la base de datos";
    } else {
        // La imagen no fue encontrada en la base de datos
        $response["message"] = "La imagen no fue encontrada en la base de datos";
        $response["success"] = false;
    }
} else {
    // La solicitud no es válida
    $response["message"] = "Solicitud no válida";
    $response["success"] = false;
}

// Devolver respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
