<?php
// conexión a la base de datos e inicio de sesión
require_once "db_con.php";
session_start();

// Array para almacenar la respuesta
$response = array();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["subir_imagen"])) {
    // recuperar datos del formulario
    $imagen = $_POST["imagen"];
    $id_antiguo = $_POST["id_antiguo"];

    // Decodificar la imagen base64
    $imagenDecodificada = base64_decode($imagen);

    // Si antes había una imagen que no era por defecto, se actualiza
    if ($id_antiguo != 0) {
        // Actualizar la imagen en la base de datos
        $queryActualizarImagen = "UPDATE imagenes SET imagen = :imagen WHERE id = :id_antiguo";
        $stmtActualizarImagen = $conexion->prepare($queryActualizarImagen);
        $stmtActualizarImagen->bindParam(':id_antiguo', $id_antiguo);
        $stmtActualizarImagen->bindParam(':imagen', $imagenDecodificada, PDO::PARAM_LOB); // Usar PDO::PARAM_LOB para datos binarios
        $stmtActualizarImagen->execute();
    } else {
        // Insertar la nueva imagen en la base de datos
        $queryInsert = "INSERT INTO imagenes (imagen) VALUES (:imagen)";
        $stmtInsert = $conexion->prepare($queryInsert);
        $stmtInsert->bindParam(':imagen', $imagenDecodificada, PDO::PARAM_LOB); // Usar PDO::PARAM_LOB para datos binarios
	    $stmtInsert->execute();

	    $idImagen = $conexion->lastInsertId();
    }

    if ($stmtActualizarImagen || $stmtInsert) {
        // La imagen se subió exitosamente
        // Devolver el ID de la nueva imagen en la respuesta JSON
        $response["idImagen"] = $id_antiguo != 0 ? $id_antiguo : $idImagen;
        $response["message"] = "La imagen se subió correctamente";
        $response["success"] = true;
        $response["imagen"] = "";
    } else {
        // Error al insertar en la base de datos
        $response["idImagen"] = -1;
        $response["message"] = "Error al insertar en la base de datos";
        $response["success"] = false;
        $response["imagen"] = "";
    } 
} else {
    // La solicitud no es válida
    $response["idImagen"] = -1;
    $response["message"] = "La solicitud ha fallado";
    $response["success"] = false;
    $response["imagen"] = "";
}

// devolver respuesta en formato json
header('Content-Type: application/json');
echo json_encode($response);

?>
