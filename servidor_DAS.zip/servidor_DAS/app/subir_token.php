<?php
// conexión a la base de datos e inicio de sesión
require_once "db_con.php";
session_start();

// Array para almacenar la respuesta
$response = array();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["subir_token"])) {
    // recuperar datos del formulario
    $tokenDispositivo = $_POST["token_dispositivo"];

    // preparar la consulta SQL para insertar el token
    $sql = "INSERT INTO dispositivos (token) VALUES (:token) ON CONFLICT DO NOTHING";
    $stmt = $conexion->prepare($sql);

    // vincular parámetros
    $stmt->bindParam(':token', $tokenDispositivo);

    // ejecutar la consulta
    try {
        if ($stmt->execute()) {
            // consulta exitosa
            $response['success'] = true;
            $response['message'] = "Token insertado con éxito";
            $response['idUsuario'] = $idUsuario;
        } else {
            // insert incorrecto
            $response['success'] = false;
            $response['message'] = "Error al insertar token";
            $response['idUsuario'] = null;
        }
    } catch (PDOException $e) {
        // gestionar la excepción cuando se produce un error inesperado
        $response['success'] = false;
        $response['message'] = "Error inesperado: " . $e->getMessage();
        $response['idUsuario'] = null;
    }
}

// Imprimir la respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
