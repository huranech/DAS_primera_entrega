<?php
// conexión a la base de datos e inicio de sesión
require_once "db_con.php";
session_start();

// Array para almacenar la respuesta
$response = array();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["login"])) {
    // recuperar datos del formulario
    $username = $_POST["newUsername"];
    $password = $_POST["newPassword"];

    // consulta SQL para verificar las credenciales del usuario
    $sql = "SELECT * FROM usuarios WHERE username = :username AND passwd = :passwd";
    $stmt = $conexion->prepare($sql);

    // hashear la contraseña
    $hashedPassword = hash('sha256', $password);

    // vincular parámetros
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':passwd', $hashedPassword);

    //ejecutar consulta
    $stmt->execute();

    // obtener el resultado de la consulta
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($resultado) {
        // Inicio de sesión exitoso
        $response['success'] = true;
        $response['message'] = "Inicio de sesión exitoso";
        $response['idUsuario'] = $resultado['id'];
    } else {
        // Credenciales incorrectas
        $response['success'] = false;
        $response['message'] = "Credenciales incorrectas. Inténtalo de nuevo.";
        $response['idUsuario'] = "-1";
    }
} else {
    // Solicitud incorrecta
    $response['success'] = false;
    $response['message'] = "Solicitud incorrecta.";
    $response['idUsuario'] = "-1";

}

// Devolver la respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
