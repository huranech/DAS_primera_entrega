<?php
// conexión a la base de datos e inicio de sesión
require_once "db_con.php";
session_start();

// Array para almacenar la respuesta
$response = array();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["eliminar_imagen"])) {
    // Recuperar el ID de la imagen del formulario
    $idImagen = $_POST["id_imagen"];

    // Consultar la base de datos para eliminar la imagen
    $query = "DELETE FROM imagenes WHERE id = :idImagen";
    $stmt = $conexion->prepare($query);
    $stmt->bindParam(":idImagen", $idImagen);
    $result = $stmt->execute();

    if ($result) {
        // La instancia de la imagen se eliminó correctamente de la base de datos
        $response["success"] = true;
        $response["message"] = "La imagen se eliminó correctamente";
        $response["idImagen"] = -1;
        $response["imagen"] = "";
    } else {
        // Error al eliminar la instancia de la imagen de la base de datos
        $response["success"] = false;
        $response["error"] = "Error al eliminar la instancia de la imagen de la base de datos";
        $response["idImagen"] = -1;
        $response["imagen"] = "";
    }
} else {
    // La solicitud no es válida
    $response["success"] = false;
    $response["error"] = "Solicitud no válida";
    $response["idImagen"] = -1;
    $response["imagen"] = "";
}

// Devolver respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
