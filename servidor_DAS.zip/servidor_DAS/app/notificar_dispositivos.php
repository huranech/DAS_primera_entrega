<?php
require_once "db_con.php";
session_start();


if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["notificar_dispositivos"])) {
    // obtener información de la receta vegana
    $nombre = $_POST["nombre"];
    $ingredientes = $_POST["ingredientes"];
    $descripcion = $_POST["descripcion"];

    // paso 1: obtener todos los tokens
    $sql = "SELECT token FROM dispositivos";
    $stmt = $conexion->prepare($sql);

    $stmt->execute();
    $tokens = $stmt->fetchAll(PDO::FETCH_COLUMN);


    // paso 2: preparar la llamada a los dispositivos
    // cabeceras
    $headers = array(
        'Authorization: key=AAAAbStI33Y:APA91bEM2r98X0hB9DhjsiVhnUbp_YwWenLAL7mwqKUlyfQf7EBPVSxLK03SnjmwfRTxhH3HmqMnqGASOhqhf6SeK6LXSpQCiWanw5gPHUBkW9jK4cKL6DP2AycS0FYnrl6ubFNBOHuj',
        'Content-Type: application/json'
    );

    $mensaje = "Nueva receta vegana \nNombre: " . $nombre . "\nIngredientes: " . $ingredientes . "\nDescripción: " . $descripcion;

    // cuerpo
    $msg = array(
        'registration_ids' => $tokens,
        'data' => array(
            'mensaje' => 'Alguien ha creado una receta vegana'
        ),
        'notification' => array(
            'body' => $mensaje,
            'title' => 'Receta vegana creada',
            'icon' => 'ic_stat_ic_notification',
        ));

    $msgJSON = json_encode($msg);

    $ch = curl_init(); #inicializar el handler de curl
    #indicar el destino de la petición, el servicio FCM de google
    curl_setopt( $ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
    #indicar que la conexión es de tipo POST
    curl_setopt( $ch, CURLOPT_POST, true );
    #agregar las cabeceras
    curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
    #Indicar que se desea recibir la respuesta a la conexión en forma de string
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
    #agregar los datos de la petición en formato JSON
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $msgJSON );
    #ejecutar la llamada
    $resultado= curl_exec( $ch );
    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
    }

    #cerrar el handler de curl
    curl_close( $ch );
}

header('Content-Type: application/json');
echo $resultado;
?>
