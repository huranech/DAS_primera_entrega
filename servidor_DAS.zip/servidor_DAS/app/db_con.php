<?php
// configuración de la conexión a PostgreSQL
$host = "db";
$dbname = "postgresdatabase";
$user = "adminuserpostgres";
$password = "pg14w45vasu5";

try {
    // conectar a la base de datos PostgreSQL
    $conexion = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
    
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión a la base de datos: " . $e->getMessage());
}
?>
