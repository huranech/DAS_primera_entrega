<?php
// conexión a la base de datos e inicio de sesión
require_once "db_con.php";
session_start();

// Array para almacenar la respuesta
$response = array();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["register"])) {
    // recuperar datos del formulario
    $newUsername = $_POST["newUsername"];
    $newPassword = $_POST["newPassword"];

    # hashear la contraseña
    $newHashedPassword = hash('sha256', $newPassword);

    // preparar la consulta SQL para insertar el nuevo usuario
    $sql = "INSERT INTO usuarios (username, passwd) VALUES (:username, :passwd)";
    $stmt = $conexion->prepare($sql);

    // vincular parámetros
    $stmt->bindParam(':username', $newUsername);
    $stmt->bindParam(':passwd', $newHashedPassword);

    // ejecutar la consulta
    try {
        if ($stmt->execute()) {
            // Obtener el ID del último registro insertado
            $idUsuario = $conexion->lastInsertId();

            // Agregar el ID a la respuesta
            $response['success'] = true;
            $response['message'] = "¡Registro exitoso! Puedes iniciar sesión ahora.";
            $response['idUsuario'] = $idUsuario;

        } else {
            // Si la inserción falla, verificar si el error es debido a que el usuario ya existe
            if ($stmt->errorInfo()[1] == 1062) {
                $response['success'] = false;
                $response['message'] = "El nombre de usuario ya está registrado. Por favor, elige otro nombre de usuario.";
                $response['idUsuario'] = -1; // Devolver ID de usuario -1 en caso de usuario existente
            } else {
                $response['success'] = false;
                $response['message'] = "Error al registrar el usuario.";
                $response['idUsuario'] = null; // Puedes establecerlo como null u omitirlo según lo necesites
            }
        }
    } catch (PDOException $e) {
        // gestionar la excepción cuando se produce un error inesperado
        $response['success'] = false;
        $response['message'] = "Error inesperado: " . $e->getMessage();
        $response['idUsuario'] = null; // Puedes establecerlo como null u omitirlo según lo necesites
    }
}

// Imprimir la respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
